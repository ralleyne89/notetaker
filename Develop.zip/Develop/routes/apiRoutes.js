const express = require('express')
const router = require('express').Router();
let Note =  require('../db/notes');
let db = require('../db/db.json');

let notes = new Note()

// creating a note
router.post('/notes', function(req, res){
    console.log(req.body)
    notes.addNotes(req.body) .then(notes => res.json(notes))
    .catch(err => res.status(500).json(err));
})

// retrieve a single note with id

router.get("/notes/:id", function (req, res){
    return res.json(db);
});

// delete a note
router.delete('/notes/:id', function(req, res){
    notes.deleteNotes(req.params.id) .then(notes => res.json(notes))
    .catch(err => res.status(500).json(err));
})

module.exports = router;